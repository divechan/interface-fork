import { ChainId } from '@sushiswap/core-sdk'

export const MigrationSupported = [ChainId.ETHEREUM, ChainId.BSC, ChainId.MATIC]
