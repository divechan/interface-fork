export const NAV_CLASS =
  'backdrop-blur-fallback w-full h-full before:backdrop-saturate-[1.2] before:backdrop-blur-[20px] before:z-[-1] before:absolute before:w-full before:h-full border-b border-dark-800'
