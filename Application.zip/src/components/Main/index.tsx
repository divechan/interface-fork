// @ts-ignore TYPE NEEDS FIXING
const Main = ({ children }) => <main className="w-full h-full">{children}</main>

export default Main
